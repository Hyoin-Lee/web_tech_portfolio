| Name        | RGB           | HEX     |
|-------------|---------------|---------|
| Black       | 0  , 0  , 0   | #000000 |
| White       | 255, 255, 255 | #FFFFFF |
| Bizarre     | 236, 217, 221 | #ECD9DD | 
| Blue Chalk  | 243, 240, 248 | #F3F0F8 |
| Canary      | 255, 255, 159 | #FFFF9F |
| Bittersweet | 254, 121, 104 | #FE7968 |


